from django.shortcuts import render
from django.http import HttpResponse
from .form import SignIn_User,SignUp_User
from django.contrib import auth
# Create your views here.
def sign_in(request):
    if request.method == "POST":
        form = SignIn_User(data=request.POST)
        if form.is_valid():
            username = request.POST["username"]
            password = request.POST["password"]
            user = auth.authenticate(username=username, password=password)
            if user:
                auth.login(request,user)
                return HttpResponse("ok")
        return HttpResponse("no ok")
    form = SignIn_User()
    return render(request,"users/sign_in2.html",context={"form":form})


def sign_up(request):
    if request.method == "POST":
        form = SignUp_User(data=request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse("ok")
    form = SignUp_User()
    return render(request,"users/sign_up.html",context={"form":form})