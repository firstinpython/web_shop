from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
# Create your models here.

class Product(models.Model):
    name = models.CharField(verbose_name="name", max_length=120)
    description = models.TextField(verbose_name="description",max_length=300)
    price = models.IntegerField(verbose_name="price", validators=[MinValueValidator(100), MaxValueValidator(100000)])
    quantity = models.IntegerField(verbose_name="quantity", validators=[MinValueValidator(0)])
    image = models.FileField(upload_to="product_image")
    is_published = models.BooleanField(default=True)
    category = models.ForeignKey(to="Categories", on_delete=models.CASCADE)
    uuid = models.CharField(null=True)


    def __str__(self):
        return f"{self.name} | {self.price} | {self.is_published}"


class Categories(models.Model):
    name = models.CharField(verbose_name="name", max_length=120)
    description = models.CharField(verbose_name="description", max_length=300)
